@echo off
setlocal
title CRACK - Desinstalar mod 8 jogadores
cd /d "%~dp0"

echo ==================================================
echo   CRACK - Desinstalar mod 8 jogadores (Crack8P)
echo ==================================================
echo.

if not exist "CRACK.exe" (
    echo [ERRO] Este arquivo precisa estar na pasta do jogo,
    echo        ao lado do CRACK.exe. Nada foi apagado.
    echo.
    pause
    exit /b 1
)

tasklist /FI "IMAGENAME eq CRACK.exe" 2>nul | find /I "CRACK.exe" >nul
if not errorlevel 1 (
    echo [ERRO] O CRACK esta aberto. Feche o jogo e rode de novo.
    echo.
    pause
    exit /b 1
)

echo Serao apagados desta pasta:
echo   - winhttp.dll
echo   - doorstop_config.ini
echo   - .doorstop_version
echo   - changelog.txt
echo   - LEIA-ME.txt
echo   - pasta BepInEx (mod, configuracoes e logs)
echo.
echo Os arquivos originais do jogo NAO serao tocados.
echo.
choice /C SN /M "Confirmar a remocao do mod"
if errorlevel 2 (
    echo Cancelado. Nada foi apagado.
    echo.
    pause
    exit /b 0
)

echo.
for %%F in ("winhttp.dll" "doorstop_config.ini" ".doorstop_version" "changelog.txt" "LEIA-ME.txt") do (
    if exist %%F (
        del /F /Q %%F
        if exist %%F (echo   [FALHOU] %%~F) else (echo   [OK] %%~F apagado)
    )
)
if exist "BepInEx\" (
    rmdir /S /Q "BepInEx"
    if exist "BepInEx\" (echo   [FALHOU] pasta BepInEx) else (echo   [OK] pasta BepInEx apagada)
)

echo.
if exist "winhttp.dll" goto falhou
if exist "BepInEx\" goto falhou
echo Mod removido. O jogo voltou ao normal (4 jogadores).
echo Este arquivo sera apagado ao fechar esta janela.
echo.
pause
(goto) 2>nul & del /F /Q "%~f0"
exit /b 0

:falhou
echo Alguns arquivos nao puderam ser apagados.
echo Tente clicar com o botao direito neste arquivo e
echo escolher "Executar como administrador", ou apague
echo manualmente os itens marcados como [FALHOU].
echo.
pause
exit /b 1
